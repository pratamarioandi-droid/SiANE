import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export const FluidBalance = () => {
  // State for intake inputs
  const [kristaloid, setKristaloid] = useState('');
  const [koloid, setKoloid] = useState('');
  const [darahIntake, setDarahIntake] = useState('');
  const [totalIntake, setTotalIntake] = useState(0);

  // State for output inputs
  const [kassa10x10Counts, setKassa10x10Counts] = useState({ '25': '', '50': '', '75': '', '100': '' });
  const [kassaBighasCounts, setKassaBighasCounts] = useState({ '25': '', '50': '', '75': '', '100': '' });
  const [luasLapang, setLuasLapang] = useState(0);
  const [urine, setUrine] = useState('');
  const [darahSuction, setDarahSuction] = useState('');
  const [cairanCuci, setCairanCuci] = useState('');
  const [totalPerdarahan, setTotalPerdarahan] = useState(0);

  useEffect(() => {
    const calcKristaloid = parseFloat(kristaloid) || 0;
    const calcKoloid = parseFloat(koloid) || 0;
    const calcDarahIntake = parseFloat(darahIntake) || 0;
    const total = (calcKristaloid / 3) + calcKoloid + calcDarahIntake;
    setTotalIntake(total);
  }, [kristaloid, koloid, darahIntake]);

  useEffect(() => {
    const kassa10x10Total =
      (parseInt(kassa10x10Counts['25'], 10) || 0) * 3 +
      (parseInt(kassa10x10Counts['50'], 10) || 0) * 6 +
      (parseInt(kassa10x10Counts['75'], 10) || 0) * 9 +
      (parseInt(kassa10x10Counts['100'], 10) || 0) * 12;
      
    const kassaBighasTotal =
      (parseInt(kassaBighasCounts['25'], 10) || 0) * 40 +
      (parseInt(kassaBighasCounts['50'], 10) || 0) * 80 +
      (parseInt(kassaBighasCounts['75'], 10) || 0) * 120 +
      (parseInt(kassaBighasCounts['100'], 10) || 0) * 160;

    const suctionNet = Math.max(0, (parseFloat(darahSuction) || 0) - (parseFloat(cairanCuci) || 0));
    const total = kassa10x10Total + kassaBighasTotal + luasLapang + suctionNet;
    setTotalPerdarahan(total);
  }, [kassa10x10Counts, kassaBighasCounts, luasLapang, darahSuction, cairanCuci]);

  const handleReset = () => {
    setKristaloid('');
    setKoloid('');
    setDarahIntake('');
    setKassa10x10Counts({ '25': '', '50': '', '75': '', '100': '' });
    setKassaBighasCounts({ '25': '', '50': '', '75': '', '100': '' });
    setLuasLapang(0);
    setUrine('');
    setDarahSuction('');
    setCairanCuci('');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Kalkulator Keseimbangan Cairan</CardTitle>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="space-y-4 p-4 border rounded-lg bg-green-50 dark:bg-green-950/50">
          <h3 className="text-xl font-semibold text-green-700 dark:text-green-400">Intake Cairan (ml)</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label htmlFor="kristaloid">Kristaloid</Label><Input id="kristaloid" type="number" value={kristaloid} onChange={(e) => setKristaloid(e.target.value)} placeholder="ml" /></div>
            <div><Label htmlFor="koloid">Koloid</Label><Input id="koloid" type="number" value={koloid} onChange={(e) => setKoloid(e.target.value)} placeholder="ml" /></div>
            <div><Label htmlFor="darahIntake">Darah</Label><Input id="darahIntake" type="number" value={darahIntake} onChange={(e) => setDarahIntake(e.target.value)} placeholder="ml" /></div>
          </div>
          <div className="p-3 font-bold text-center rounded-lg bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">Total Intake: {totalIntake.toFixed(2)} ml</div>
        </div>

        <div className="space-y-4 p-4 border rounded-lg bg-red-50 dark:bg-red-950/50">
          <h3 className="text-xl font-semibold text-red-700 dark:text-red-400">Output Cairan (ml)</h3>
          
          <div className="p-4 border rounded-md">
            <h4 className="font-semibold mb-2">Perdarahan Tersembunyi</h4>
            <div className="space-y-4">
              <div>
                <Label>Kassa 10x10 Basah (jumlah)</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-1">
                  {Object.entries(kassa10x10Counts).map(([pct, val]) => (
                    <div key={pct}><Label className="text-sm">{pct}%</Label><Input type="number" value={val} onChange={e => setKassa10x10Counts({...kassa10x10Counts, [pct]: e.target.value})} placeholder="pcs" /></div>
                  ))}
                </div>
              </div>
              <div>
                <Label>Kassa Perut (Bighas) Basah (jumlah)</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-1">
                  {Object.entries(kassaBighasCounts).map(([pct, val]) => (
                    <div key={pct}><Label className="text-sm">{pct}%</Label><Input type="number" value={val} onChange={e => setKassaBighasCounts({...kassaBighasCounts, [pct]: e.target.value})} placeholder="pcs" /></div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 border rounded-md">
            <h4 className="font-semibold mb-2">Output Terukur</h4>
            <div className="space-y-4">
              <div>
                <Label>Luas Lapang Operasi</Label>
                <RadioGroup onValueChange={(val) => setLuasLapang(Number(val))} value={String(luasLapang)} className="flex space-x-4 mt-1">
                  <div className="flex items-center space-x-2"><RadioGroupItem value="25" id="kecil" /><Label htmlFor="kecil">Kecil (25ml)</Label></div>
                  <div className="flex items-center space-x-2"><RadioGroupItem value="75" id="sedang" /><Label htmlFor="sedang">Sedang (75ml)</Label></div>
                  <div className="flex items-center space-x-2"><RadioGroupItem value="125" id="besar" /><Label htmlFor="besar">Besar (125ml)</Label></div>
                </RadioGroup>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div><Label htmlFor="urine">Jumlah Urine</Label><Input id="urine" type="number" value={urine} onChange={(e) => setUrine(e.target.value)} placeholder="ml" /></div>
                <div><Label htmlFor="darahSuction">Darah di Suction</Label><Input id="darahSuction" type="number" value={darahSuction} onChange={(e) => setDarahSuction(e.target.value)} placeholder="ml" /></div>
                <div><Label htmlFor="cairanCuci">Cairan Cuci</Label><Input id="cairanCuci" type="number" value={cairanCuci} onChange={(e) => setCairanCuci(e.target.value)} placeholder="ml" /></div>
              </div>
            </div>
          </div>
          <div className="p-3 font-bold text-center rounded-lg bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200">Total Perdarahan: {totalPerdarahan.toFixed(2)} ml</div>
        </div>

        <Button onClick={handleReset} variant="destructive" className="w-full">Reset Data</Button>
      </CardContent>
    </Card>
  );
};