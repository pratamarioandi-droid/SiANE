import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export const BmiCalculator = () => {
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [bmi, setBmi] = useState<number | null>(null);
  const [category, setCategory] = useState("");
  const [interpretation, setInterpretation] = useState("");
  const [categoryClass, setCategoryClass] = useState("");
  const [error, setError] = useState("");

  const calculateBmi = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBmi(null);

    const heightNum = parseFloat(height);
    const weightNum = parseFloat(weight);

    if (isNaN(heightNum) || isNaN(weightNum) || heightNum <= 0 || weightNum <= 0) {
      setError("Mohon masukkan tinggi dan berat badan yang valid.");
      return;
    }

    const heightInMeters = heightNum / 100;
    const bmiValue = weightNum / (heightInMeters * heightInMeters);
    setBmi(bmiValue);

    let cat = '';
    let interp = '';
    let catClass = '';

    if (bmiValue < 18.5) {
        cat = 'Kurus (Underweight)';
        interp = 'Anda memiliki berat badan kurang. Disarankan untuk meningkatkan asupan kalori dengan makanan bergizi.';
        catClass = 'bg-yellow-100 text-yellow-800';
    } else if (bmiValue < 25) {
        cat = 'Normal';
        interp = 'Berat badan Anda ideal. Pertahankan pola makan seimbang dan olahraga teratur.';
        catClass = 'bg-green-100 text-green-800';
    } else if (bmiValue < 30) {
        cat = 'Gemuk (Overweight)';
        interp = 'Anda memiliki berat badan berlebih. Disarankan untuk mengatur pola makan dan meningkatkan aktivitas fisik.';
        catClass = 'bg-orange-100 text-orange-800';
    } else if (bmiValue < 35) {
        cat = 'Obesitas Kelas I';
        interp = 'Anda berada dalam kategori obesitas kelas I. Sangat disarankan untuk berkonsultasi dengan dokter atau ahli gizi.';
        catClass = 'bg-red-100 text-red-800';
    } else if (bmiValue < 40) {
        cat = 'Obesitas Kelas II';
        interp = 'Anda berada dalam kategori obesitas kelas II. Konsultasi dengan tenaga medis profesional sangat penting untuk rencana penanganan.';
        catClass = 'bg-red-200 text-red-900';
    } else {
        cat = 'Obesitas Kelas III';
        interp = 'Anda berada dalam kategori obesitas kelas III (morbid). Segera cari bantuan medis profesional untuk penanganan lebih lanjut.';
        catClass = 'bg-red-300 text-red-900';
    }
    
    setCategory(cat);
    setInterpretation(interp);
    setCategoryClass(catClass);
  };

  const resetCalculator = () => {
    setHeight("");
    setWeight("");
    setBmi(null);
    setCategory("");
    setInterpretation("");
    setCategoryClass("");
    setError("");
  };

  return (
    <div className="w-full max-w-3xl bg-white rounded-2xl shadow-xl p-6 md:p-10 mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-800">BMI Calculator</h1>
        <p className="text-lg md:text-xl text-gray-500 mt-1">RSUD SIDOARJO BARAT</p>
      </div>

      <form onSubmit={calculateBmi} className="space-y-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="height" className="block text-sm font-medium text-gray-700 mb-2">Tinggi Badan (cm)</Label>
            <Input
              type="number"
              id="height"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 h-auto"
              placeholder="Contoh: 170"
            />
          </div>
          <div>
            <Label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-2">Berat Badan (kg)</Label>
            <Input
              type="number"
              id="weight"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 h-auto"
              placeholder="Contoh: 65"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-300 transition-transform transform hover:scale-105 duration-200 h-auto">
            Hitung BMI
          </Button>
          <Button type="button" onClick={resetCalculator} className="w-full bg-gray-200 text-gray-700 font-bold py-3 px-4 rounded-lg hover:bg-gray-300 focus:outline-none focus:ring-4 focus:ring-gray-400 transition duration-200 h-auto" variant="secondary">
            Reset
          </Button>
        </div>
      </form>

      {error && (
        <div className="text-center p-4 my-4 bg-red-100 text-red-700 rounded-lg">
          {error}
        </div>
      )}

      {bmi !== null && !error && (
        <div className="text-center p-6 bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Hasil BMI Anda</h3>
          <p className="text-5xl font-extrabold mb-2">{bmi.toFixed(2)}</p>
          <p className={cn("text-xl font-semibold px-4 py-1 rounded-full inline-block", categoryClass)}>{category}</p>
          <p className="text-gray-600 mt-4 max-w-md mx-auto">{interpretation}</p>
        </div>
      )}

      <div className="mt-10 pt-6 border-t border-gray-200">
        <h4 className="text-lg font-semibold text-gray-800 text-center mb-4">Referensi Kategori BMI (Menurut WHO)</h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center text-sm">
          <div className="p-3 bg-yellow-100 text-yellow-800 rounded-lg"><p className="font-bold">Kurus</p><p>&lt; 18.5</p></div>
          <div className="p-3 bg-green-100 text-green-800 rounded-lg"><p className="font-bold">Normal</p><p>18.5 - 24.9</p></div>
          <div className="p-3 bg-orange-100 text-orange-800 rounded-lg"><p className="font-bold">Gemuk</p><p>25.0 - 29.9</p></div>
          <div className="p-3 bg-red-100 text-red-800 rounded-lg"><p className="font-bold">Obesitas Kelas I</p><p>30.0 - 34.9</p></div>
          <div className="p-3 bg-red-200 text-red-900 rounded-lg"><p className="font-bold">Obesitas Kelas II</p><p>35.0 - 39.9</p></div>
          <div className="p-3 bg-red-300 text-red-900 rounded-lg"><p className="font-bold">Obesitas Kelas III</p><p>≥ 40.0</p></div>
        </div>
      </div>
    </div>
  );
};