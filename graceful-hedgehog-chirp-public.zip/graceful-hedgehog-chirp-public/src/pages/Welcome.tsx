import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Scale, Pill, Droplets, Beaker } from "lucide-react";

const menuItems = [
  { to: "/bmi", icon: Scale, label: "BMI Calculator", color: "text-blue-600 dark:text-blue-400", bgColor: "bg-blue-50/80 dark:bg-blue-900/70" },
  { to: "/dosage", icon: Pill, label: "Dosis Obat", color: "text-green-600 dark:text-green-400", bgColor: "bg-green-50/80 dark:bg-green-900/70" },
  { to: "/ebl", icon: Droplets, label: "EBL Calculator", color: "text-red-600 dark:text-red-400", bgColor: "bg-red-50/80 dark:bg-red-900/70" },
  { to: "/fluid-balance", icon: Beaker, label: "Fluid Balance", color: "text-yellow-600 dark:text-yellow-400", bgColor: "bg-yellow-50/80 dark:bg-yellow-900/70" },
];

const Welcome = () => {
  return (
    <div className="space-y-6">
      <div className="text-center p-4">
        <p className="text-lg text-gray-600 dark:text-gray-400">Selamat Datang Di</p>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-teal-500">
            Si Ane MedCalc
          </span>
        </h1>
        <p className="text-xl font-semibold text-gray-700 dark:text-gray-300">RSUD Sidoarjo Barat</p>
      </div>

      <Card className="overflow-hidden border-0 shadow-xl">
        <CardContent className="p-0 relative">
          <img 
            src="/images/Kamar-Operasi-RS.jpg" 
            alt="Kamar Operasi RSUD Sidoarjo Barat" 
            className="w-full h-auto object-cover max-h-[500px]"
          />
          <div className="absolute inset-0 bg-black/30 flex items-center justify-center p-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full max-w-3xl">
              {menuItems.map((item) => (
                <Link to={item.to} key={item.to} className="no-underline group">
                  <div className={`h-full p-4 flex flex-col items-center justify-center text-center rounded-lg shadow-lg backdrop-blur-sm transition-all duration-300 group-hover:scale-105 group-hover:shadow-xl ${item.bgColor}`}>
                    <item.icon className={`h-12 w-12 mb-2 transition-transform duration-300 group-hover:rotate-6 ${item.color}`} />
                    <span className="font-semibold text-base text-gray-800 dark:text-gray-100">{item.label}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-sm text-gray-600 dark:text-gray-400 pt-4 text-center">
        Aplikasi ini menyediakan beberapa alat bantu hitung medis untuk keperluan anestesiologi. Silakan pilih salah satu kalkulator dari menu untuk memulai.
      </p>
    </div>
  );
};

export default Welcome;