import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const medicationData = [
    {
        group: "Obat-obatan Premedikasi",
        items: [
            { name: "Sulfat Atropin", min: 0.01, max: 0.02, unit: "mg" },
            { name: "Midazolam", min: 0.05, max: 0.1, unit: "mg" }
        ]
    },
    {
        group: "Obat-obatan Induksi",
        items: [
            { name: "Fentanyl", min: 2, max: 5, unit: "mcg" },
            { name: "Propofol", min: 1.5, max: 2.5, unit: "mg" },
            { name: "Ketamin", min: 1, max: 2, unit: "mg" },
            { name: "Atracurium", min: 0.5, max: 0.6, unit: "mg" },
            { name: "Rocuronium", min: 0.6, max: 1.2, unit: "mg" },
            { name: "Vencuronium", min: 0.1, max: 0.2, unit: "mg" }
        ]
    },
    {
        group: "Obat-obatan Post Operasi",
        items: [
            { name: "Dexamethasone", min: 0.1, max: 0.2, unit: "mg" },
            { name: "Ranitidin", min: 1, max: 2, unit: "mg" },
            { name: "Ondansentron", min: 0.1, max: 0.15, unit: "mg" },
            { name: "Metamizole", min: 15, max: 20, unit: "mg" },
            { name: "Ketorolac", min: 0.5, max: 1, unit: "mg" },
            { name: "Furosemide", min: 0.5, max: 1, unit: "mg" },
            { name: "Naloxone", min: 5, max: 10, unit: "mcg" },
            { name: "Neostigmin", min: 0.04, max: 0.07, unit: "mg" }
        ]
    }
];

type Result = {
  name: string;
  doseRange: string;
  resultText: string;
};

type GroupedResults = {
  [category: string]: Result[];
};

type AdditionalInfo = {
    tidalVolume: string;
    ettSize: string;
    lmaSize: string;
    suctionSize: string;
}

export const DrugDosage = () => {
  const [weight, setWeight] = useState("");
  const [results, setResults] = useState<GroupedResults | null>(null);
  const [additionalInfo, setAdditionalInfo] = useState<AdditionalInfo | null>(null);
  const [error, setError] = useState("");

  const formatNumber = (num: number) => parseFloat(num.toFixed(3));

  const calculateDoses = () => {
    const weightNum = parseFloat(weight);
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Harap masukkan berat badan yang valid.");
      setResults(null);
      setAdditionalInfo(null);
      return;
    }
    setError("");

    const grouped = medicationData.reduce((acc, group) => {
        acc[group.group] = group.items.map(drug => {
            const minResult = formatNumber(drug.min * weightNum);
            const maxResult = formatNumber(drug.max * weightNum);
            const resultText = `${minResult} - ${maxResult} ${drug.unit}`;
            const doseRange = `${drug.min}-${drug.max} ${drug.unit}/kg`;
            return { name: drug.name, doseRange, resultText };
        });
        return acc;
    }, {} as GroupedResults);
    setResults(grouped);

    // Additional Calculations
    let ettSizeMin = 0, ettSizeMax = 0, lmaSize = 0;
    if (weightNum < 10) { ettSizeMin = 3.0; ettSizeMax = 4.0; lmaSize = weightNum < 5 ? 1 : 1.5; }
    else if (weightNum < 20) { ettSizeMin = 4.0; ettSizeMax = 5.0; lmaSize = 2; }
    else if (weightNum < 30) { ettSizeMin = 5.0; ettSizeMax = 6.0; lmaSize = 2.5; }
    else if (weightNum < 50) { ettSizeMin = 6.0; ettSizeMax = 6.5; lmaSize = 3; }
    else if (weightNum < 70) { ettSizeMin = 7.0; ettSizeMax = 7.5; lmaSize = 4; }
    else { ettSizeMin = 7.5; ettSizeMax = 8.5; lmaSize = 5; }

    setAdditionalInfo({
        tidalVolume: `${formatNumber(weightNum * 6)} - ${formatNumber(weightNum * 8)} cc`,
        ettSize: `${ettSizeMin} - ${ettSizeMax}`,
        lmaSize: `${lmaSize}`,
        suctionSize: `${(ettSizeMin - 1) * 2}`
    });
  };

  const resetForm = () => {
    setWeight("");
    setResults(null);
    setAdditionalInfo(null);
    setError("");
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Kalkulator Dosis Obat Anestesi</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg mb-6">
          <div>
            <Label htmlFor="weight">Berat Badan (kg)</Label>
            <Input id="weight" type="number" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="Contoh: 70" />
          </div>
          <div className="flex space-x-3">
            <Button onClick={calculateDoses} className="w-full">Hitung</Button>
            <Button onClick={resetForm} variant="destructive" className="w-full">Reset</Button>
          </div>
        </div>

        {error && <p className="text-red-500 text-center mb-4">{error}</p>}

        {results && (
          <div className="space-y-8">
            {Object.entries(results).map(([category, drugs]) => (
              <div key={category}>
                <h3 className="text-xl font-semibold mb-3 text-gray-700 dark:text-gray-200">{category}</h3>
                <div className="overflow-x-auto"><Table>
                    <TableHeader><TableRow><TableHead>Nama Obat</TableHead><TableHead>Dosis</TableHead><TableHead>Hasil (Min - Max)</TableHead></TableRow></TableHeader>
                    <TableBody>{drugs.map((drug) => (<TableRow key={drug.name}><TableCell className="font-medium">{drug.name}</TableCell><TableCell>{drug.doseRange}</TableCell><TableCell className="font-semibold text-indigo-600 dark:text-indigo-400">{drug.resultText}</TableCell></TableRow>))}</TableBody>
                </Table></div>
              </div>
            ))}
          </div>
        )}

        {additionalInfo && (
            <div className="mt-8">
                <h3 className="text-xl font-semibold mb-3 text-gray-700 dark:text-gray-200">Informasi Tambahan</h3>
                <div className="overflow-x-auto"><Table>
                    <TableHeader><TableRow><TableHead>Parameter</TableHead><TableHead>Ukuran</TableHead></TableRow></TableHeader>
                    <TableBody>
                        <TableRow><TableCell>Tidal Volume</TableCell><TableCell>{additionalInfo.tidalVolume}</TableCell></TableRow>
                        <TableRow><TableCell>Ukuran Endotracheal Tube (ETT)</TableCell><TableCell>{additionalInfo.ettSize}</TableCell></TableRow>
                        <TableRow><TableCell>Ukuran Laryngeal Mask Airway (LMA)</TableCell><TableCell>{additionalInfo.lmaSize}</TableCell></TableRow>
                        <TableRow><TableCell>Ukuran Suction Catheter</TableCell><TableCell>{additionalInfo.suctionSize}</TableCell></TableRow>
                    </TableBody>
                </Table></div>
            </div>
        )}

        <div className="mt-8 text-center text-xs text-gray-500 dark:text-gray-400 italic">
          <p><strong>Penting:</strong> Kalkulator ini hanya sebagai alat bantu estimasi. Dosis yang sebenarnya harus disesuaikan dengan kondisi klinis pasien dan kebijakan institusi.</p>
        </div>
      </CardContent>
    </Card>
  );
};