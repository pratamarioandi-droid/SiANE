import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const ResultCard = ({ title, ebl, hb, className }: { title: string, ebl: string, hb: string, className?: string }) => (
  <div className={cn("p-4 rounded-xl border transform transition-transform hover:scale-105", className)}>
    <h3 className="font-bold text-xl mb-2">{title}</h3>
    <div className="mt-2">
      <p className="text-sm text-gray-600 dark:text-gray-400">Estimasi EBL</p>
      <p className="text-2xl font-semibold">{ebl}</p>
    </div>
    <div className="mt-4">
      <p className="text-sm text-gray-600 dark:text-gray-400">Estimasi Sisa Hb</p>
      <p className="text-2xl font-semibold">{hb}</p>
    </div>
  </div>
);

export const EblCalculator = () => {
  const [weight, setWeight] = useState("");
  const [hemoglobin, setHemoglobin] = useState("");
  const [gender, setGender] = useState("");
  const [results, setResults] = useState<{ ebl: string; hb: string; }[] | null>(null);

  const calculateEbl = () => {
    const weightNum = parseFloat(weight);
    const initialHb = parseFloat(hemoglobin);

    if (isNaN(weightNum) || isNaN(initialHb) || !gender || weightNum <= 0 || initialHb <= 0) {
      alert('Harap isi semua data dengan benar (Berat Badan, Hemoglobin, dan Jenis Kelamin).');
      return;
    }

    const ebvMultiplier = gender === 'pria' ? 75 : 65;
    const estimatedBloodVolume = weightNum * ebvMultiplier;
    const percentages = [10, 15, 20, 30];

    const newResults = percentages.map(percent => {
      const lossFraction = percent / 100;
      const ebl = estimatedBloodVolume * lossFraction;
      const newHb = initialHb - (initialHb * lossFraction);
      return {
        ebl: `${ebl.toFixed(0)} ml`,
        hb: `${newHb.toFixed(2)} g/dL`
      };
    });
    setResults(newResults);
  };

  const resetForm = () => {
    setWeight("");
    setHemoglobin("");
    setGender("");
    setResults(null);
  };

  const resultColors = [
    "bg-blue-50 dark:bg-blue-900/50 border-blue-200 dark:border-blue-700 text-blue-900 dark:text-blue-200",
    "bg-green-50 dark:bg-green-900/50 border-green-200 dark:border-green-700 text-green-900 dark:text-green-200",
    "bg-yellow-50 dark:bg-yellow-900/50 border-yellow-300 dark:border-yellow-700 text-yellow-900 dark:text-yellow-200",
    "bg-orange-50 dark:bg-orange-900/50 border-orange-300 dark:border-orange-700 text-orange-900 dark:text-orange-200",
  ];

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Kalkulator Perdarahan (EBL)</CardTitle>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Hitung Estimasi Kehilangan Darah (Estimated Blood Loss) Selama Operasi
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div>
            <Label htmlFor="weight">Berat Badan (kg)</Label>
            <Input id="weight" type="number" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="Contoh: 70" />
          </div>
          <div>
            <Label htmlFor="hemoglobin">Kadar Hemoglobin (g/dL)</Label>
            <Input id="hemoglobin" type="number" value={hemoglobin} onChange={(e) => setHemoglobin(e.target.value)} placeholder="Contoh: 14" />
          </div>
          <div>
            <Label htmlFor="gender">Jenis Kelamin</Label>
            <Select value={gender} onValueChange={setGender}>
              <SelectTrigger id="gender">
                <SelectValue placeholder="Pilih Jenis Kelamin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pria">Pria</SelectItem>
                <SelectItem value="wanita">Wanita</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <Button onClick={calculateEbl}>Hitung</Button>
          <Button onClick={resetForm} variant="destructive">Reset</Button>
        </div>

        {results && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-center">
            <ResultCard title="Kehilangan 10%" ebl={results[0].ebl} hb={results[0].hb} className={resultColors[0]} />
            <ResultCard title="Kehilangan 15%" ebl={results[1].ebl} hb={results[1].hb} className={resultColors[1]} />
            <ResultCard title="Kehilangan 20%" ebl={results[2].ebl} hb={results[2].hb} className={resultColors[2]} />
            <ResultCard title="Kehilangan 30%" ebl={results[3].ebl} hb={results[3].hb} className={resultColors[3]} />
          </div>
        )}
      </CardContent>
    </Card>
  );
};