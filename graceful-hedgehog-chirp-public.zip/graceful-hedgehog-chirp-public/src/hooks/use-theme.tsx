import * as React from "react";

export function useTheme() {
  const [theme, setThemeState] = React.useState<"light" | "dark">(
    window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
  );

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const setTheme = (theme: "light" | "dark") => {
    setThemeState(theme);
  };

  return { theme, setTheme };
}