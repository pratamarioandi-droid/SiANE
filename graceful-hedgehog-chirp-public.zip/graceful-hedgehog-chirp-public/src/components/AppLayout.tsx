import { Outlet } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { NavLink } from "@/components/NavLink";
import { ThemeToggle } from "@/components/ThemeToggle";
import { MadeWithDyad } from "@/components/made-with-dyad";
import { Scale, Pill, Droplets, Home, Beaker } from "lucide-react";

const AppLayout = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Logo />
          <ThemeToggle />
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <nav className="w-full md:w-64 bg-white dark:bg-gray-800 rounded-lg shadow p-4 h-fit md:sticky md:top-24">
            <h2 className="text-lg font-semibold mb-4 px-4">Menu</h2>
            <ul className="space-y-1">
              <li>
                <NavLink to="/">
                  <Home className="mr-3 h-5 w-5" />
                  Menu Utama
                </NavLink>
              </li>
              <li>
                <NavLink to="/bmi">
                  <Scale className="mr-3 h-5 w-5 text-blue-500" />
                  BMI Calculator
                </NavLink>
              </li>
              <li>
                <NavLink to="/dosage">
                  <Pill className="mr-3 h-5 w-5 text-green-500" />
                  Dosis Obat
                </NavLink>
              </li>
              <li>
                <NavLink to="/ebl">
                  <Droplets className="mr-3 h-5 w-5 text-red-500" />
                  EBL Calculator
                </NavLink>
              </li>
              <li>
                <NavLink to="/fluid-balance">
                  <Beaker className="mr-3 h-5 w-5 text-yellow-500" />
                  Fluid Balance
                </NavLink>
              </li>
            </ul>
          </nav>
          
          <div className="flex-1">
            <Outlet />
          </div>
        </div>
      </main>
      
      <MadeWithDyad />
    </div>
  );
};

export default AppLayout;