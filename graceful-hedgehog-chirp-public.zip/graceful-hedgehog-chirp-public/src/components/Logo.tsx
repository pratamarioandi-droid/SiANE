import { Stethoscope } from "lucide-react";
import { Link } from "react-router-dom";

export const Logo = () => {
  return (
    <Link to="/" className="flex items-center gap-2 text-current no-underline">
      <Stethoscope className="h-8 w-8 text-blue-600" />
      <div>
        <h1 className="text-xl font-bold">Si Ane MedCalc</h1>
        <p className="text-xs text-gray-500 dark:text-gray-400">Sistem Informasi Anestesi Medical Calculator</p>
        <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">RSUD Sidoarjo Barat</p>
      </div>
    </Link>
  );
};